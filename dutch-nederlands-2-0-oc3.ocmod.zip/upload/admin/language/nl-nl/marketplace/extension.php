<?php
// Heading
$_['heading_title'] = 'Extensies';

// Text
$_['text_success']  = 'Je hebt extensies bijgewerkt!';
$_['text_list']     = 'Extensielijst';
$_['text_type']     = 'Kies een type extensie';
$_['text_filter']   = 'Filter';