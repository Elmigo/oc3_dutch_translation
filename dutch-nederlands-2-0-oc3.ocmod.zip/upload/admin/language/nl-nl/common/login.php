<?php
// Heading
$_['heading_title']  = 'Administratie';

// Text
$_['text_heading']   = 'Administratie';
$_['text_login']     = 'Vul je inloggegevens in.';
$_['text_forgotten'] = 'Wachtwoord vergeten';

// Entry
$_['entry_username'] = 'Gebruikersnaam';
$_['entry_password'] = 'Wachtwoord';

// Button
$_['button_login']   = 'Inloggen';

// Error
$_['error_login']    = 'De gebruikersnaam en het wachtwoord komen niet overeen.';
$_['error_token']    = 'Invalid token session. Please login again.';