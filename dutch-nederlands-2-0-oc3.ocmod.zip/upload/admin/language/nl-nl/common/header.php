<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = 'Jouw profiel';
$_['text_store']         = 'Winkels';
$_['text_help']          = 'Help';
$_['text_homepage']      = 'OpenCart-home';
$_['text_support']       = 'Ondersteuning';
$_['text_documentation'] = 'Documentatie';
$_['text_logout']        = 'Uitloggen';