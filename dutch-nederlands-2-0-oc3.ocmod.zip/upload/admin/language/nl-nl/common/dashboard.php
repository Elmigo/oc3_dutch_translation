<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install'] = 'De installatiemap bestaat nog steeds en moet worden verwijderd uit de site root map!';