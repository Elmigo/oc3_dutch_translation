<?php
// Heading
$_['heading_title'] = 'Rapporten';

// Text
$_['text_success']  = 'Je hebt rapporten bewerkt!';
$_['text_list']     = 'Rapportenlijst';
$_['text_type']     = 'Kies het rapporttype';
$_['text_filter']   = 'Filteren';