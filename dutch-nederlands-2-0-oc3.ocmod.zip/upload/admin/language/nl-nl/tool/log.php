<?php
// Heading
$_['heading_title']    = 'Error-logbestand';

// Text
$_['text_success']     = 'Het error-logbestand is succesvol vrijgemaakt!';
$_['text_list']        = 'Lijst van errors';

// Error
$_['error_warning']    = 'Het error-logbestand %s is %s!';
$_['error_permission'] = 'Je hebt geen toestemming om het error-logbestand vrij te maken!';