<?php
// Text
$_['text_subject'] = '%s - Je affiliate registratie is afgewezen!';
$_['text_welcome'] = 'Bedankt voor je affiliate registratie bij %s!';
$_['text_denied']  = 'Helaas is je affiliate account afgewezen. Voor meer informatie kun je contact opnemen:';
$_['text_thanks']  = 'Bedankt,';