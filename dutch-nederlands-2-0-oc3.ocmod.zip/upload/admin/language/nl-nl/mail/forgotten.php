<?php
// Text
$_['text_subject']  = '%s - Wachtwoord wijziging';
$_['text_greeting'] = 'Een nieuw wachtwoord is aangevraagd voor %s administratie.';
$_['text_change']   = 'Om je wachtwoord te herstellen klik je op:';
$_['text_ip']       = 'Het IP adres dat is gebruikt voor deze aanvraag is:';