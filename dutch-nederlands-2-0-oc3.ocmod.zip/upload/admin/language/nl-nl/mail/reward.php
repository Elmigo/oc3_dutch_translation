<?php
// Text
$_['text_subject']  = '%s - Spaarpunten';
$_['text_received'] = 'Je hebt %s spaarpunten ontvangen!';
$_['text_total']    = 'Je totale aantal spaarpunten is nu %s.';