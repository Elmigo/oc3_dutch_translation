<?php
// Text
$_['text_subject']  = '%s - Je affiliate account is geactiveerd!';
$_['text_welcome']  = 'Bedankt voor je registratie bij %s!';
$_['text_login']    = 'Je account is goedgekeurd en je kunt nu inloggen op onze website of met de volgende URL';
$_['text_services'] = 'Nadat je bent ingelogd kun je traceercodes aanmaken, commissies bewerken en je account bewerken.';
$_['text_thanks']   = 'Bedankt,';