<?php
// Text
$_['text_success']  = 'Je hebt cadeaukaarten bijgewerkt!';
$_['text_subject']  = 'Cadeaukaart van %s';
$_['text_greeting'] = 'Gefeliciteerd, je hebt een cadeaukaart gekregen met een waarde van %s';
$_['text_from']     = 'Deze cadeaukaart is afkomstig van %s';
$_['text_message']  = 'met het volgende bericht:';
$_['text_redeem']   = 'Om deze cadeaukaart te gebruiken, schrijf de volgende kaartcode op: <b>%s</b> en klik op de onderstaande link om producten te kopen. Je kunt de kaartcode invoeren in je winkelwagentje vóór je gaat afrekenen.';
$_['text_footer']   = 'Beantwoord deze e-mail als je nog vragen hebt.';