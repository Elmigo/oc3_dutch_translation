<?php
// Text
$_['text_subject'] = '%s - Je accountregistratie is afgewezen!';
$_['text_welcome'] = 'Bedankt voor je registratie bij %s!';
$_['text_denied']  = 'Helaas is je registratie afgewezen. Voor meer informatie kun je contact opnemen:';
$_['text_thanks']  = 'Bedankt,';
