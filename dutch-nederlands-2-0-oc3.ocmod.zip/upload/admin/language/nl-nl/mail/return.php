<?php
// Text
$_['text_subject']       = '%s - Retournering update %s';
$_['text_return_id']     = 'Retournering ID:';
$_['text_date_added']    = 'Retourneerdatum:';
$_['text_return_status'] = 'De status van je retournering is veranderd naar:';
$_['text_comment']       = 'Opmerkingen:';
$_['text_footer']        = 'Beantwoord deze e-mail als er nog vragen zijn.';