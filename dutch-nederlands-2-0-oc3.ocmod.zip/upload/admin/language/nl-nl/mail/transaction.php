<?php
// Text
$_['text_subject']  = '%s - Affiliate krediet';
$_['text_received'] = 'Je hebt %s krediet ontvangen!';
$_['text_total']    = 'Je kredietbalans is nu %s.';
$_['text_credit']   = 'Je account krediet kan worden afgetrokken van je volgende aankoop.';