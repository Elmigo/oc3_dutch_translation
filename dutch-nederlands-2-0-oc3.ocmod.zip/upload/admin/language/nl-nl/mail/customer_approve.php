<?php
// Text
$_['text_subject'] = '%s - Je account is geactiveerd!';
$_['text_welcome'] = 'Bedankt voor je registratie bij %s!';
$_['text_login']   = 'Je account is aangemaakt:';
$_['text_service'] = 'Nadat je bent ingelogd kun je je bestelgeschiedenis bekijken, bestellingen beoordelen, je account bewerken en meer.';
$_['text_thanks']  = 'Bedankt,';