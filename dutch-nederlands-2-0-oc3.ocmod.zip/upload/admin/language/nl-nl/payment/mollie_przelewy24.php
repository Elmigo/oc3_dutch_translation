<?php
require(dirname(__FILE__) . "/mollie.php");

$_['heading_title'] .= " &ndash; " . $_['name_mollie_przelewy24'];
