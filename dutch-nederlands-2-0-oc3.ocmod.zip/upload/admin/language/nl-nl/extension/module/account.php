<?php
// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt account module bijgewerkt!';
$_['text_edit']        = 'Account module bewerken';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om account module te bewerken!';