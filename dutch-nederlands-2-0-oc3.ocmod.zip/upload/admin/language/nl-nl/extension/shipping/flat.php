<?php
// Heading
$_['heading_title']    = 'Standaard verzendkosten';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt de standaard verzendkosten bijgewerkt!';
$_['text_edit']        = 'Standaard verzendkosten';

// Entry
$_['entry_cost']       = 'Kosten';
$_['entry_tax_class']  = 'Belasting klasse';
$_['entry_geo_zone']   = 'Geozone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om standaard verzendkosten te bewerken!';