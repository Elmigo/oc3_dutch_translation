<?php
// Heading
$_['heading_title']    = 'Afhalen bij winkel';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt afhalen bij winkel bijgewerkt!';
$_['text_edit']        = 'Afhalen bij winkel bewerken';

// Entry
$_['entry_geo_zone']   = 'Geozone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om afhalen bij winkel te bewerken!';