<?php
// Heading
$_['heading_title']    = 'Per item';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt verzendkosten per item bijgewerkt!';
$_['text_edit']        = 'Verzendkosten per item bewerken';

// Entry
$_['entry_cost']       = 'Kosten';
$_['entry_tax_class']  = 'Belasting klasse';
$_['entry_geo_zone']   = 'Geozone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om verzendkosten per item te bewerken!';