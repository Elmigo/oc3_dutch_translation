<?php
// Heading
$_['heading_title']    = 'Klanten totaal';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt klanten in dashboard bijgewerkt!';
$_['text_edit']        = 'Klanten in dashboard bewerken';
$_['text_view']        = 'Meer bekijken...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om klanten in het dashboard te bewerken!';