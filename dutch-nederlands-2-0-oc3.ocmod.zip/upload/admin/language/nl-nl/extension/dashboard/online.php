<?php
// Heading
$_['heading_title']    = 'Online personen';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt online op dashboard bewerkt!';
$_['text_edit']        = 'Online op dashboard bewerken';
$_['text_view']        = 'Meer bekijken...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om online op het dashboard te bewerken!';