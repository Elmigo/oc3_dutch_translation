<?php
// Heading
$_['heading_title']    = 'Totale verkopen';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt verkopen in dashboard bijgewerkt!';
$_['text_edit']        = 'Bewerk verkopen in dashboard';
$_['text_view']        = 'Meer bekijken...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om verkopen in het dashboard te bewerken!';