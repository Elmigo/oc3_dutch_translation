<?php
// Heading
$_['heading_title']    = 'Bestellingen totaal';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt bestellingen op dashboard bijgewerkt!';
$_['text_edit']        = 'Dashboard bestellingen bewerken';
$_['text_view']        = 'Meer bekijken...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';
$_['entry_width']      = 'Breedte';

// Error
$_['error_permission'] = 'Je hebt geen toestemmingen om bestellingen op dashboard te bewerken!';