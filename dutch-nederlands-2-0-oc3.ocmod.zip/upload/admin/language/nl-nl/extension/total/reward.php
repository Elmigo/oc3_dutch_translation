<?php
// Heading
$_['heading_title']    = 'Spaarpunten';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt spaarpunten bijgewerkt!';
$_['text_edit']        = 'Spaarpunten bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om spaarpunten te bewerken!';