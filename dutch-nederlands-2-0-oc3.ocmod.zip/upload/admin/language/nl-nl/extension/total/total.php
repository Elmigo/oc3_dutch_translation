<?php
// Heading
$_['heading_title']    = 'Totaal';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt totalen bijgewerkt!';
$_['text_edit']        = 'Totalen bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om totalen te bewerken!';