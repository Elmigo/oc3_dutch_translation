<?php
// Heading
$_['heading_title']    = 'Belastingen';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt belastingen bijgewerkt!';
$_['text_edit']        = 'Belastingen bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om belastingen te bewerken!';