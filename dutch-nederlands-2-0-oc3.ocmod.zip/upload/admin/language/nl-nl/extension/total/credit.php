<?php
// Heading
$_['heading_title']    = 'Winkelkrediet';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt het winkelkrediet bijgewerkt!';
$_['text_edit']        = 'Winkelkrediet bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om winkelkrediet te bewerken!';