<?php
// Heading
$_['heading_title']    = 'Cadeaukaart';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt de cadeaukaart bijgewerkt!';
$_['text_edit']        = 'Cadeaukaart bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om de cadeaukaart te bewerken!';