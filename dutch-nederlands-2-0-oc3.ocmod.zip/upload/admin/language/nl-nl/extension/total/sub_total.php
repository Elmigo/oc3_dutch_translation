<?php
// Heading
$_['heading_title']    = 'Subtotaal';

// Text
$_['text_extension']   = 'Extensies';
$_['text_success']     = 'Je hebt subtotalen bijgewerkt';
$_['text_edit']        = 'Subtotalen bewerken';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om subtotalen te bewerken!';