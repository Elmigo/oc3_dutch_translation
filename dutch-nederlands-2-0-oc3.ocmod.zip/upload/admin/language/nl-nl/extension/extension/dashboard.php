<?php
// Heading
$_['heading_title']     = 'Dashboard';

// Text
$_['text_success']      = 'Je hebt dashboards bijgewerkt!';
$_['text_list']         = 'Dashboard lijst';

// Column
$_['column_name']       = 'Dashboard naam';
$_['column_width']      = 'Breedte';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om dashboards te bewerken!';