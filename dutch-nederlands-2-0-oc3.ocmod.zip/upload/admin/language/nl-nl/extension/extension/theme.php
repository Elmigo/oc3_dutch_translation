<?php
// Heading
$_['heading_title']    = 'Thema\'s';

// Text
$_['text_success']     = 'Je hebt thema\'s bewerkt!';
$_['text_list']        = 'Themalijst';

// Column
$_['column_name']      = 'Theme';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om thema\'s te bewerken!';