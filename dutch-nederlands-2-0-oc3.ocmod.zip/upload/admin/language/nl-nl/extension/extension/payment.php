<?php
// Heading
$_['heading_title']     = 'Betalingen';

// Text
$_['text_success']      = 'Je hebt betalingen bijgewerkt!';
$_['text_list']         = 'Betalingenlijst';


// Column
$_['column_name']       = 'Betaalmethode';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om betalingen te bewerken!!';