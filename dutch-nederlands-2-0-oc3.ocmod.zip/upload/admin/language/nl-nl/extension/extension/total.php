<?php
// Heading
$_['heading_title']     = 'Bestellingen totaal';

// Text
$_['text_success']      = 'Je hebt totalen bijgewerkt!';
$_['text_list']         = 'Totalen bewerken';

// Column
$_['column_name']       = 'Bestellingen totaal';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om de totalen te bewerken!';