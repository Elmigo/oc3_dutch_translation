<?php
// Heading
$_['heading_title']    = 'Feeds';

// Text
$_['text_success']     = 'Je hebt feeds bijgewerkt!';
$_['text_list']        = 'Feed lijst';

// Column
$_['column_name']      = 'Feed naam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om feeds te bewerken!';