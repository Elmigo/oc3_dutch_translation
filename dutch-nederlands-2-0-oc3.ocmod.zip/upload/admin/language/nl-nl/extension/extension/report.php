<?php
// Heading
$_['heading_title']     = 'Rapporten';

// Text
$_['text_success']      = 'Je hebt rapporten bijgewerkt!';
$_['text_list']         = 'Rapportenlijst';

// Column
$_['column_name']       = 'Rapport';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om rapporten te bewerken!';