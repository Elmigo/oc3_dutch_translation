<?php
// Heading
$_['heading_title']     = 'Overig';

// Text
$_['text_success']      = 'Je hebt overige extenties bijgewerkt!';
$_['text_list']         = 'Overige lijst';

// Column
$_['column_name']       = 'Overige';
$_['column_status']     = 'Status';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om overige te bewerken!';