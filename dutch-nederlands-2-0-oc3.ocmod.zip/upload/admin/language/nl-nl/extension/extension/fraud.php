<?php
// Heading
$_['heading_title']    = 'Anti-Fraud';

// Text
$_['text_success']     = 'Je hebt anti-fraude instellingen bijgewerkt!';
$_['text_list']        = 'Anti-fraude lijst';

// Column
$_['column_name']      = 'Anti-fraude naam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om anti-fraude instellingen te bewerken!';