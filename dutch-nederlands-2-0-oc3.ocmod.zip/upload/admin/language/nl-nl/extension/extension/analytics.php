<?php
// Heading
$_['heading_title']    = 'Analyses';

// Text
$_['text_success']     = 'Je hebt analyses bijgewerkt!';
$_['text_list']        = 'Analyselijst';

// Column
$_['column_name']      = 'Analysenaam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om analyses te bewerken!';