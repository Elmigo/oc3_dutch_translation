<?php
// Heading
$_['heading_title']    = 'Marketing';

// Text
$_['text_success']     = 'Je hebt marketinginstellingen bijgewerkt!';
$_['text_list']        = 'Analyselijst';

// Column
$_['column_name']      = 'Marketingnaam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om marketinginstellingen te bewerken!';