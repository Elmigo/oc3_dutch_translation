<?php
// Heading
$_['heading_title']     = 'Verzending';

// Text
$_['text_success']      = 'Je hebt verzending bijgewerkt!';
$_['text_list']         = 'Verzendlijst';

// Column
$_['column_name']       = 'Verzendmethode';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Actie';

// Error
$_['error_permission']  = 'Je hebt geen toestemming om verzendingen te bewerken!';