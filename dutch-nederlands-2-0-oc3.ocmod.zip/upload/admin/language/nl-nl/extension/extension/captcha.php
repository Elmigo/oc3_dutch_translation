<?php
// Heading
$_['heading_title']    = 'Captchas';

// Text
$_['text_success']     = 'Je hebt captcha\'s bijgewerkt!';
$_['text_list']        = 'Captchalijst';

// Column
$_['column_name']      = 'Captchanaam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om captcha\'s te bewerken!';