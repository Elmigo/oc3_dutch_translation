<?php
// Heading
$_['heading_title']    = 'Menu';

// Text
$_['text_success']     = 'Je hebt het menu bijgewerkt!';
$_['text_list']        = 'Menulijst';

// Column
$_['column_name']      = 'Menunaam';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actie';

// Error
$_['error_permission'] = 'Je hebt geen toestemming om het menu te bewerken!';