<?php
    include(__DIR__."/../../payment/mollie_klarnasliceit.php");