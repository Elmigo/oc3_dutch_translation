<?php
    include(__DIR__."/../../payment/mollie_giropay.php");