<?php
    include(__DIR__."/../../payment/mollie_przelewy24.php");