<?php
// Heading
$_['heading_title']  = 'Pagina niet gevonden!';

// Text
$_['text_not_found'] = 'De pagina die je hebt opgevraagd kon niet worden gevonden. Neem contact op met de admin van het syteem als dit probleem blijft bestaan.';