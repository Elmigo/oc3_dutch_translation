<?php
// Heading
$_['heading_title']   = 'Toestemming afgewezen!';

// Text
$_['text_permission'] = 'Je hebt geen toegang tot deze pagina. Neem contact op met de admin van het systeem.';