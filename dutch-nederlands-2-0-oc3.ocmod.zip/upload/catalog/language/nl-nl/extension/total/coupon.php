
<?php
// Heading
$_['heading_title'] = 'Waardebon';

// Text
$_['text_coupon']   = 'Waardebon (%s)';
$_['text_success']  = 'Je waardebon is toegepast!';

// Entry
$_['entry_coupon']  = 'Waardebon code';

// Error
$_['error_coupon']  = 'De waardebon is ongeldig of heeft de limiet bereikt!';
$_['error_empty']   = 'Verzilver een waardebon!';