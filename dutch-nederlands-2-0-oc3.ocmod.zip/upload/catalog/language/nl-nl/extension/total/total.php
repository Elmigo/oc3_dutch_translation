<?php
// Text
$_['text_total'] = 'Totaal';