<?php
// Heading
$_['heading_title'] = 'Cadeaukaart';

// Text
$_['text_voucher']  = 'Cadeaukaart (%s)';
$_['text_success']  = 'Je cadeaukaart is toegepast!';

// Entry
$_['entry_voucher'] = 'Cadeaukaart code';

// Error
$_['error_voucher'] = 'De cadeaukaart is ongeldig of heeft de limiet bereikt!';
$_['error_empty']   = 'Verzilver een cadeaukaart!';