<?php
// Text
$_['text_credit']   = 'Winkelkrediet';
$_['text_order_id'] = 'Bestelling ID: #%s';