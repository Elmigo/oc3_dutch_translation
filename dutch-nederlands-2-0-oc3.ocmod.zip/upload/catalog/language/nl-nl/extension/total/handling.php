<?php
// Text
$_['text_handling'] = 'Administratiekosten';