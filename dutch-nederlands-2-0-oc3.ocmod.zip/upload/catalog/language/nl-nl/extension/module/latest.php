<?php
// Heading
$_['heading_title'] = 'Nieuwe producten';

// Text
$_['text_tax']      = 'Excl. BTW:';