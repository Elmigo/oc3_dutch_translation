<?php
// Heading
$_['heading_title'] = 'Zoekopdracht filteren';