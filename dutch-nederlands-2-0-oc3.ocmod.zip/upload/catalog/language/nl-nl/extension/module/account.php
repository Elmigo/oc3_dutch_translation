
<?php
// Heading
$_['heading_title']    = 'Account';

// Text
$_['text_register']    = 'Registreren';
$_['text_login']       = 'Inloggen';
$_['text_logout']      = 'Uitloggen';
$_['text_forgotten']   = 'Wachtwoord vergeten';
$_['text_account']     = 'Mijn Account';
$_['text_edit']        = 'Account bewerken';
$_['text_password']    = 'Wachtwoord';
$_['text_address']     = 'Adressen';
$_['text_wishlist']    = 'Verlanglijstje';
$_['text_order']       = 'Geschiedenis';
$_['text_download']    = 'Downloads';
$_['text_reward']      = 'Spaarpunten';
$_['text_return']      = 'Retourneringen';
$_['text_transaction'] = 'Transacties';
$_['text_newsletter']  = 'Updates';
$_['text_recurring']   = 'Abonnementen';