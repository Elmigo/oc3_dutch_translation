<?php
// Heading
$_['heading_title'] = 'Aanbiedingen';

// Text
$_['text_tax']      = 'Excl. BTW:';