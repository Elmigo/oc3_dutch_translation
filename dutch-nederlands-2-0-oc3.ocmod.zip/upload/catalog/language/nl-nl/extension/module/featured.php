<?php
// Heading
$_['heading_title'] = 'Aanbevolen';

// Text
$_['text_tax']      = 'Excl. BTW:';