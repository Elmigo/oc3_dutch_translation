<?php
// Heading
$_['heading_title'] = 'Best verkocht';

// Text
$_['text_tax']      = 'Excl. BTW:';