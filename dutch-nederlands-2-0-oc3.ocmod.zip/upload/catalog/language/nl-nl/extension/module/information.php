<?php
// Heading
$_['heading_title'] = 'Informatie';

// Text
$_['text_contact']  = 'Contact opnemen';
$_['text_sitemap']  = 'Sitemap';