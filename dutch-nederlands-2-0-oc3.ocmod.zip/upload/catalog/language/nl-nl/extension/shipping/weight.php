<?php
// Text
$_['text_title']  = 'Zending gebaseerd op gewicht';
$_['text_weight'] = 'Gewicht:';