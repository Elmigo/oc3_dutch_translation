<?php
// Text
$_['text_title']       = 'Afhalen';
$_['text_description'] = 'Afhalen bij winkel';