<?php
// Text
$_['text_title']       = 'Gratis verzending';
$_['text_description'] = 'Gratis verzending';