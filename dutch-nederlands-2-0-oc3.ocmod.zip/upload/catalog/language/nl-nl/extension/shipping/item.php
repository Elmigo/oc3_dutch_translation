<?php
// Text
$_['text_title']       = 'Per product';
$_['text_description'] = 'Verzendkosten per product';