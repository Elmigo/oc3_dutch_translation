<?php
// Text
$_['text_title']       = 'Verzendkosten';
$_['text_description'] = 'Verzendkosten per bestelling';