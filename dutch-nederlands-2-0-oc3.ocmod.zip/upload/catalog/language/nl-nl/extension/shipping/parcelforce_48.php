<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Gewicht:';
$_['text_insurance']   = 'Verzekerd tot:';
$_['text_time']        = 'Geschatte tijd: binnen 48 uren';