<?php
// Text
$_['text_title'] = 'Credit / Debit Card / Paypal / Wallet (G2APay)';