<?php

// Text
$_['text_cron_email_message'] = '<p>Dit is een geautomatiseerd rapport van de meest recente CRON taak, uitgevoerd door jouw Google Shopping extension.</p><p>%s</p>';
$_['text_cron_email_subject'] = 'CRON takenrapport - Google Shopping on OpenCart';
$_['text_per_day']            = '$%s / dag';
