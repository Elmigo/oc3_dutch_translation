<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Voer de code in het veld hieronder in';

// Error
$_['error_captcha'] = 'De verificatiecode komt niet overeen met de afbeelding!';