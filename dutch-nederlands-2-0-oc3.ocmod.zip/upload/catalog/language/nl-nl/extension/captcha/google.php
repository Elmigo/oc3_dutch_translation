<?php
// Text
$_['text_captcha']  = 'Validatie';

// Entry
$_['entry_captcha'] = '';

// Error
$_['error_captcha'] = 'Verification is not correct!';