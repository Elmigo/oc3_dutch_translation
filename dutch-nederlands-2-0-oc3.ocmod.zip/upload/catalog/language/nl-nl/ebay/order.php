<?php
//Order totals
$_['lang_shipping']     = 'Verzendkosten';
$_['lang_discount']     = 'Korting';
$_['lang_tax']          = 'BTW';
$_['lang_subtotal']     = 'Subtotaal';
$_['lang_total']        = 'Totaal';
?>