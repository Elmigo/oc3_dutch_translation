<?php
// Text
$_['text_information']  = 'Voorwaarden';
$_['text_service']      = 'Winkelservice';
$_['text_extra']        = 'Extra\'s';
$_['text_contact']      = 'Contact opnemen';
$_['text_return']       = 'Retourneren';
$_['text_sitemap']      = 'Sitemap';
$_['text_manufacturer'] = 'Merken';
$_['text_voucher']      = 'Cadeaukaarten';
$_['text_affiliate']    = 'Voor affiliates';
$_['text_special']      = 'Aanbiedingen';
$_['text_account']      = 'Mijn account';
$_['text_order']        = 'Geschiedenis';
$_['text_wishlist']     = 'Verlanglijstje';
$_['text_newsletter']   = 'Updates';
$_['text_powered']      = 'Ontwikkeld door <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s en vertaald door <a href="http://www.elmigo.nl">Elmigo</a>';