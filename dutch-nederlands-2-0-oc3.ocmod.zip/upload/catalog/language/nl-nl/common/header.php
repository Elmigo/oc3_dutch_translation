<?php
// Text
$_['text_home']          = 'Home';
$_['text_wishlist']      = 'Verlanglijstje (%s)';
$_['text_shopping_cart'] = 'Winkelwagentje';
$_['text_category']      = 'Categorieën';
$_['text_account']       = 'Mijn account';
$_['text_register']      = 'Registreren';
$_['text_login']         = 'Inloggen';
$_['text_order']         = 'Geschiedenis';
$_['text_transaction']   = 'Transacties';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Uitloggen';
$_['text_checkout']      = 'Afrekenen';
$_['text_search']        = 'Zoeken';
$_['text_all']           = 'Alles weergeven';