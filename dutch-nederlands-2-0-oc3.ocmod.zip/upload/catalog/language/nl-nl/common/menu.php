<?php
// Text
$_['text_all'] = 'Alles tonen';