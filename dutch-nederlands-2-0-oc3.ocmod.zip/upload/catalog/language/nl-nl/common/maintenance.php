<?php
// Heading
$_['heading_title']    = 'Onderhoud';

// Text
$_['text_maintenance'] = 'Onderhoud';
$_['text_message']     = '<h1 style="text-align:center;">Momenteel wordt de website onderhouden. <br/>Wij zijn zo snel mogelijk weer terug!</h1>';