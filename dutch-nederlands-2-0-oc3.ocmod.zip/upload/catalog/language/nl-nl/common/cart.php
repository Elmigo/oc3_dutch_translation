<?php
// Text
$_['text_items']     = '%s artikel(en) - %s';
$_['text_empty']     = 'Je winkelwagentje is leeg!';
$_['text_cart']      = 'Bekijken';
$_['text_checkout']  = 'Afrekenen';
$_['text_recurring'] = 'Betaalprofiel';