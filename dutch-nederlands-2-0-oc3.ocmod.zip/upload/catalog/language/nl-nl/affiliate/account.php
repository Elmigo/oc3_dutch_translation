<?php
// Heading 
$_['heading_title']        = 'Mijn Affiliate Account';

// Text
$_['text_account']         = 'Account';
$_['text_my_account']      = 'Affiliate Account';
$_['text_my_tracking']     = 'Tracking Informatie';
$_['text_my_transactions'] = 'Transacties';
$_['text_edit']            = 'Gegevens wijzigen';
$_['text_password']        = 'Wachtwoord wijzigen';
$_['text_payment']         = 'Betaalgegevens wijzigen';
$_['text_tracking']        = 'Affiliate Tracking Code';
$_['text_transaction']     = 'Betaalgeschiedenis';
?>