<?php
// Heading 
$_['heading_title'] = 'Uitloggen';

// Text
$_['text_message']  = '<p>U bent succesvol uitgelogd.</p>';
$_['text_account']  = 'Account';
$_['text_logout']   = 'Uitloggen';
?>