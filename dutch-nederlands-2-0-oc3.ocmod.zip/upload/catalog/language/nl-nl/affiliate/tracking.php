<?php
// Heading 
$_['heading_title']    = 'Affiliate Tracking';

// Text
$_['text_account']     = 'Account';
$_['text_description'] = 'Om er voor te zorgen dat u betaald krijgt voor de links geplaatst op uw wesbite dient u aan deze link een Tracking code to te voegen. Deze kunt u hieronder genereren.';
$_['text_code']        = '<b>Uw Tracking Code:</b>';
$_['text_generator']   = '<b>Tracking Link Generator</b><br />Geef de naam van het product waarnaar u wilt linken:';
$_['text_link']        = '<b>Tracking Link:</b>';
?>