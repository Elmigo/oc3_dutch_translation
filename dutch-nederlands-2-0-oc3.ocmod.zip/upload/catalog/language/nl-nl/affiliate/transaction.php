<?php
// Heading 
$_['heading_title']      = 'Uw Transacties';

// Column
$_['column_date_added']  = 'Datum';
$_['column_description'] = 'Omschrijving';
$_['column_amount']      = 'Bedrag (%s)';

// Text
$_['text_account']       = 'Account';
$_['text_transaction']   = 'Uw transacties';
$_['text_balance']       = 'Uw huidge balance is:';
$_['text_empty']         = 'U heeft nog geen transacties!';
?>