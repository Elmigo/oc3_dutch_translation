<?php
// Text
$_['text_success']       = 'Klanten zijn bijgewerkt.';

// Error
$_['error_permission']   = 'Je hebt geen toegang tot deze API.';
$_['error_customer']     = 'Je moet een klant selecteren!';
$_['error_firstname']    = 'Voornaam moet tussen 1 en 32 tekens bevatten!';
$_['error_lastname']     = 'Achternaam moet tussen 1 en 32 tekens bevatten!';
$_['error_email']        = 'Dit e-mail adres is niet correct!';
$_['error_telephone']    = 'Dit telefoonnummer is niet correct';
$_['error_custom_field'] = '%s is vereist!';