<?php
// Text
$_['text_success']     = 'Je hebt je winkelwagentje gewijzigd.';

// Error
$_['error_permission'] = 'Je hebt geen toegang tot de API.';
$_['error_stock']      = 'Producten die zijn gemarkeerd met *** zijn niet in de gewenste hoeveelheid beschikbaar, of niet op voorraad.';
$_['error_minimum']    = 'De minimale hoeveelheid voor %s is %s!';
$_['error_store']      = 'Het product kan niet gekocht worden bij de door jou gekozen winkel.';
$_['error_required']   = '%s is vereist!';