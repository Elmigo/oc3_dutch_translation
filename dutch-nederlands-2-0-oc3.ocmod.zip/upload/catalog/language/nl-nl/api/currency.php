<?php
// Text
$_['text_success']     = 'De valuta is gewijzigd!';

// Error
$_['error_permission'] = 'Je hebt geen toegang tot deze API.';
$_['error_currency']   = 'De valutacode is ongeldig.';