<?php
// Text
$_['text_success'] = 'API sessie is gestart!';

// Error
$_['error_key']    = 'Ongeldige API sleutel!';
$_['error_ip']     = 'Het IP-adres %s is heeft geen toegang tot deze API!';