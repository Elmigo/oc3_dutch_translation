<?php
// Text
$_['text_success']     = 'Korting toegevoegd!';

// Error
$_['error_permission'] = 'Je hebt geen toegang tot deze API.';
$_['error_coupon']     = 'Je cadeaukaart is niet geldig of heeft de limiet bereikt.';