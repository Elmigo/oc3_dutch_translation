<?php
// Text
$_['text_success']     = 'Je spaarpunten zijn toegepast!';

// Error
$_['error_permission'] = 'Je hebt geen toegang tot deze API.';
$_['error_reward']     = 'Vul het aantal te gebruiken spaarpunten in!';
$_['error_points']     = 'Je hebt niet genoeg spaarpunten!';
$_['error_maximum']    = 'Het maximum aantal spaarpunten dat kan worden toegepast is %s!';