<?php
// Text
$_['text_subject']      = '%s - De status van je bestelling %s';
$_['text_order_id']     = 'Bestelling ID:';
$_['text_date_added']   = 'Datum toegevoegd:';
$_['text_order_status'] = 'De status van je bestelling is gewijzigd naar:';
$_['text_comment']      = 'Opmerkingen:';
$_['text_link']         = 'Om je bestelling te bekijken, klik op de volgende link:';
$_['text_footer']       = 'Beantwoord deze e-mail als er nog vragen zijn.';