<?php
// Text
$_['text_subject']  = '%s - Wijziging wachtwoord';
$_['text_greeting'] = 'Er is een nieuw wachtwoord aangevraagd voor %s klantaccount.';
$_['text_change']   = 'Om je wachtwoord te herstellen, klik op de link hieronder:';
$_['text_ip']       = 'Het IP adres dat is gebruikt voor deze aanvraag is:';