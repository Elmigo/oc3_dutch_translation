<?php
// Text
$_['text_subject']  = 'Cadeaukaart van %s';
$_['text_greeting'] = 'Gefeliciteerd, je hebt een cadeaukaart gekregen met een waarde van %s';
$_['text_from']     = 'Deze cadeaukaart is afkomstig van %s';
$_['text_message']  = 'Bericht:';
$_['text_redeem']   = 'Bewaar deze e-mail goed! Voer kaartcode <b>%s</b> in je winkelwagentje in vóór je gaat afrekenen. Klik op de onderstaande link om direct te winkelen.';
$_['text_footer']   = 'Beantwoord deze e-mail als je nog vragen hebt.';