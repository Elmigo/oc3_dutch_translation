<?php
// Text
$_['text_subject']  = '%s - Affiliate commissie';
$_['text_received'] = 'Gefeliciteerd! Je hebt een betaling ontvangen van het %s affiliate programma';
$_['text_amount']   = 'Je hebt ontvangen::';
$_['text_total']    = 'Je totale commissies zijn nu:';