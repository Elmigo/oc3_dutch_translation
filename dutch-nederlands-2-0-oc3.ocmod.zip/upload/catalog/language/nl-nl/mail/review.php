<?php
// Text
$_['text_subject']  = '%s - Productbeoordeling';
$_['text_waiting']  = 'Er wacht een nieuwe productbeoordeling op goedkeuring!';
$_['text_product']  = 'Product: %s';
$_['text_reviewer'] = 'Beoordeler: %s';
$_['text_rating']   = 'Beoordeling: %s';
$_['text_review']   = 'Review:';