<?php
// Text
$_['text_subject']      = '%s - Bestelling %s';
$_['text_received']     = 'Je hebt een bestelling ontvangen.';
$_['text_order_id']     = 'Bestelling ID:';
$_['text_date_added']   = 'Datum toegevoegd:';
$_['text_order_status'] = 'Status bestelling:';
$_['text_product']      = 'Producten';
$_['text_total']        = 'Totaal';
$_['text_comment']      = 'Opmerkingen:';
