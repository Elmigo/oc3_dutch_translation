<?php
// Heading
$_['heading_title'] = 'Niet gevonden...';

// Text
$_['text_error']    = 'De opgevraagde pagina kon niet worden gevonden.';