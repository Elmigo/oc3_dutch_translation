<?php
// Heading
$_['heading_title']      = 'Spaarpunten';

// Column
$_['column_date_added']  = 'Datum toegevoegd';
$_['column_description'] = 'Omschrijving';
$_['column_points']      = 'Spaarpunten';

// Text
$_['text_account']       = 'Account';
$_['text_reward']        = 'Spaarpunten';
$_['text_total']         = 'Aantal spaarpunten:';
$_['text_empty']         = 'Je hebt geen spaarpunten.';