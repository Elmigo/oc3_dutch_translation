<?php
// Heading
$_['heading_title']    = 'Nieuws en aanbiedingen ontvangen';

// Text
$_['text_account']     = 'Account';
$_['text_newsletter']  = 'Updates';
$_['text_success']     = 'Je voorkeur voor het ontvangen van nieuws en aanbiedingen is bijgewerkt!';

// Entry
$_['entry_newsletter'] = 'Updates ontvangen';