<?php
// Heading
$_['heading_title']      = 'Transacties';

// Column
$_['column_date_added']  = 'Datum toegevoegd';
$_['column_description'] = 'Omschrijving';
$_['column_amount']      = 'Aantal (%s)';

// Text
$_['text_account']       = 'Account';
$_['text_transaction']   = 'Transacties';
$_['text_total']         = 'Huidige balans:';
$_['text_empty']         = 'Je hebt nog geen transacties.';