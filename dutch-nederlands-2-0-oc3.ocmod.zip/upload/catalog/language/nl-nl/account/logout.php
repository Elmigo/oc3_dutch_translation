<?php
// Heading
$_['heading_title'] = 'Uitloggen';

// Text
$_['text_message']  = '<p>Je bent uitgelogd.</p><p>Producten in het winkelwagentje zijn opgeslagen.</p>';
$_['text_account']  = 'Account';
$_['text_logout']   = 'Uitloggen';