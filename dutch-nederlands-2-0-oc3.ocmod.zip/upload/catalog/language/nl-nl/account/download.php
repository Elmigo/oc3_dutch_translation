<?php
// Heading
$_['heading_title']     = 'Mijn downloads';

// Text
$_['text_account']      = 'Account';
$_['text_downloads']    = 'Downloads';
$_['text_empty']        = 'Je hebt nog geen digitale producten gekocht.';

// Column
$_['column_order_id']   = 'Bestelling ID';
$_['column_name']       = 'Naam';
$_['column_size']       = 'Grootte';
$_['column_date_added'] = 'Datum van aankoop';