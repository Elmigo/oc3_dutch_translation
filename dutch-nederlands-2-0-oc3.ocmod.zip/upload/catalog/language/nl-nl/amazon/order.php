<?php
//Text
$_['paid_on_amazon_text'] = 'Betaald via Amazon';

//Order totals
$_['shipping_text'] = 'Verzendkosten';
$_['shipping_tax_text'] = 'BTW. verzendkosten';
$_['gift_wrap_text'] = 'Cadeauverpakking';
$_['gift_wrap_tax_text'] = 'BTW. cadeauverpakking';
$_['sub_total_text'] = 'Sub-Totaal';
$_['tax_text'] = 'BTW.';
$_['total_text'] = 'Totaal'; 
?>