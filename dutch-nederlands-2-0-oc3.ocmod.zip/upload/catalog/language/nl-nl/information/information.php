<?php
// Text
$_['text_error'] = 'De informatiepagina is niet gevonden!';