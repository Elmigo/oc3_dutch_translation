<?php
// Heading
$_['heading_title']    = 'Sitemap';

// Text
$_['text_special']     = 'Aanbiedingen';
$_['text_account']     = 'Account';
$_['text_edit']        = 'Accountgegevens';
$_['text_password']    = 'Wachtwoord';
$_['text_address']     = 'Adresboek';
$_['text_history']     = 'Bestelgeschiedenis';
$_['text_download']    = 'Downloads';
$_['text_cart']        = 'Winkelwagentje';
$_['text_checkout']    = 'Afrekenen';
$_['text_search']      = 'Zoeken';
$_['text_information'] = 'Informatie';
$_['text_contact']     = 'Contact opnemen';